
export const svg1 = "https://dm-frontend.s3.amazonaws.com/sme-journey/svg-1.svg";
export const svg2 = "https://dm-frontend.s3.amazonaws.com/sme-journey/svg-2.svg";
export const svg3 = "https://dm-frontend.s3.amazonaws.com/sme-journey/svg-3.svg";
export const svg4 = "https://dm-frontend.s3.amazonaws.com/sme-journey/svg-4.svg";
export const svg5 = "https://dm-frontend.s3.amazonaws.com/sme-journey/svg-5.svg";
export const svg6 = "https://dm-frontend.s3.amazonaws.com/sme-journey/svg-6.svg";
export const svg7 = "https://dm-frontend.s3.amazonaws.com/sme-journey/svg-7.svg";
export const svg8 = "https://dm-frontend.s3.amazonaws.com/sme-journey/svg-8.svg";
export const svg9 = "https://dm-frontend.s3.amazonaws.com/sme-journey/svg-9.svg";
export const svg10 = "https://dm-frontend.s3.amazonaws.com/sme-journey/svg-10.svg";
export const capgLogo = "https://dm-frontend.s3.amazonaws.com/sme-journey/capgLogo.svg";
export const heroSectionbg = "https://dm-frontend.s3.amazonaws.com/sme-journey/herosectionbg.jpg";
export const herosectionbg2 = "https://dm-frontend.s3.amazonaws.com/sme-journey/herosectionbg2.jpg";